function A = warmUpExercise()

A = eye(5);

end
